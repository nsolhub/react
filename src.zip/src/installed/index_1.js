import React from "react";
import ReactDom from "react-dom";
import "bootstrap/dist/css/bootstrap.css";

const element = <h1> Pakistan Zindabad</h1>;
console.log(element);
ReactDom.render(element, document.getElementById("root"));
