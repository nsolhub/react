import React, { Component } from "react";
class Counter extends Component {
  state = {
    count: 1,
    app: 0
  };

  showinfo(para) {
    return para.name + " " + para.age + " " + para.city;
  }
  user = {
    firstName: "Harper",
    lastName: "Perez"
  };
  my = {
    name: "raheel",
    age: 24,
    city: "isb"
  };
  element = <h1> {this.showinfo(this.my.age)}</h1>;

  render() {
    return (
      <React.Fragment>
        <h1 className="jumbotron">
          Hello Pakistan {this.formatCount()} and {this.state.app}
        </h1>
        <h2>buhaha</h2>

        <button>Increament</button>
      </React.Fragment>
    );
  }
  render() {
    return (
      <React.Fragment>
        <h1 className="btn btn-primary"> {this.showinfo(this.my)}</h1>

        <h2>buhaha</h2>

        <button>Increament</button>
      </React.Fragment>
    );
  }

  formatCount() {
    const { count } = this.state;
    return this.state.app === count ? "okay" : count;
  }
}

export default Counter;
